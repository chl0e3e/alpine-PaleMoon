// ==UserScript==
// @name        MSVS
// @namespace   MSVS
// @description Downloads the Visual Studio installer
// @include     https://visualstudio.microsoft.com/downloads/
// @version     1
// @grant       none
// ==/UserScript==

window.addEventListener('load', function() {
    document.querySelector("[data-bi-name='vs_win_download_community']").click();
}, false);
